package homeWork.Person;

import java.io.Serializable;

@SuppressWarnings("unused")
public enum Gender implements Serializable {
    MALE,
    FEMALE
}
